export class Student {
    id: number;
    serialNumber: string;
    name: string;
    groupNumber: number;
}