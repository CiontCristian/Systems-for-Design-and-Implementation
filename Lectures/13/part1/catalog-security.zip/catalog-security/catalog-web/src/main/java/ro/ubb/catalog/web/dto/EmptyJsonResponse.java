package ro.ubb.catalog.web.dto;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

/**
 * Created by radu.
 */
@JsonSerialize
public class EmptyJsonResponse  {
}
