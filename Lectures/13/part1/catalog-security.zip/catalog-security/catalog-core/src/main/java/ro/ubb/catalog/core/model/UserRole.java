package ro.ubb.catalog.core.model;

/**
 * Created by radu.
 */
public enum UserRole {
    STUDENT,
    TEACHER,
    ADMIN
}
