package ro.ubb.catalog.core.service;

import ro.ubb.catalog.core.model.Pizza;

import java.util.List;

/**
 * author: radu
 */
public interface PizzaService {

    List<Pizza> findAll();



}
