export class Pizza{
  id: number;
  name: string;
  price: number;
}
