package ro.ubb.crud.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import ro.ubb.crud.model.Person;

import javax.persistence.*;
import java.util.List;

/**
 * author: radu
 *
 * new -> managed
 * managed -> removed | detached | 'db'
 * removed -> managed | detached | 'db'
 * 'db' -> managed
 */
@Repository
public class PersonRepositoryImpl implements PersonRepository {
    @Autowired
    private EntityManagerFactory entityManagerFactory;

    @Override
    public void save(Person person) {
        //person is in New aka Transient state (see class Main)

        EntityManager entityManager =
                entityManagerFactory.createEntityManager();
        EntityTransaction transaction = entityManager.getTransaction();
        transaction.begin();

        entityManager.persist(person);
        //person is now in Managed state

        transaction.commit();
        //person is now saved in the db

        entityManager.close();

    }

    @Override
    public List<Person> getPersonsByName(String name) {
        EntityManager entityManager =
                entityManagerFactory.createEntityManager();

        String sql = "select p from Person p where p.name=?1";
        TypedQuery<Person> query = entityManager.createQuery(sql, Person.class);
        query.setParameter(1, name);
        List<Person> persons = query.getResultList();
        //persons are in Managed state

        entityManager.close();
        return persons;
    }

    @Override
    public Person findById1(Long id) {
        System.out.println("find1===========");
        EntityManager entityManager =
                entityManagerFactory.createEntityManager();

        Person person = entityManager.find(Person.class, id);
        //person is in Managed state
        System.out.println("find1-person: ");
        System.out.println(person);

        Person person2 = entityManager.find(Person.class, id);
        //check logs after each find() call
        System.out.println("find1-person2: ");
        System.out.println(person2);

        entityManager.close();
        //person is in Detached state

        return person;
    }

    @Override
    public Person findById2(Long id) {
        System.out.println("find2===========");
        EntityManager entityManager =
                entityManagerFactory.createEntityManager();

        Person person = entityManager.getReference(Person.class, id);
        //check logs; uncomment souts (try different combinations)
        //compare logs from getReference() with the logs from find()
        System.out.println("find2-person: ");
//        System.out.println(person);

        Person person2 = entityManager.getReference(Person.class, id);
        System.out.println("find2-person2: ");
//        System.out.println(person2);

        entityManager.close();
        return person;
    }

    @Override
    public void update(Person person) {
        //person is in Detached state (see class Main)

        System.out.println("update============");
        EntityManager entityManager =
                entityManagerFactory.createEntityManager();
        EntityTransaction transaction = entityManager.getTransaction();
        transaction.begin();

        Person updatePerson = entityManager
                .getReference(Person.class, person.getId());

        updatePerson.setName("p2");
        //updatePerson is in Managed state

        transaction.commit();
        //changes to Managed entities saved in the db

        entityManager.close();
        //updatePerson is in Detached state
    }

    @Override
    public void deleteById(Long id) {
        System.out.println("delete============");
        EntityManager entityManager =
                entityManagerFactory.createEntityManager();
        EntityTransaction transaction = entityManager.getTransaction();
        transaction.begin();

        Person personDelete = entityManager
                .getReference(Person.class, id);
        //personDelete is in Managed state

        entityManager.remove(personDelete);
        //personDelete is in Removed state
        //calling persist() would change the state to Managed

        transaction.commit();
        //personDelete is removed from the db

        entityManager.close();
        //personDelete is in Detached state
    }

    @Override
    public void merge1(Person person) {
        //person is in Detached state (see class Main)

        System.out.println("merge1");
        EntityManager entityManager =
                entityManagerFactory.createEntityManager();
        EntityTransaction transaction = entityManager.getTransaction();
        transaction.begin();

        person.setName("p3");
        entityManager.merge(person);
        //person is Managed

        transaction.commit();
        //changes to Managed entities - saved in the db

        entityManager.close();
        //person Detached
    }

    @Override
    public void merge2(Person person) {
        //person is in Transient state (see class Main)

        System.out.println("merge2");
        EntityManager entityManager =
                entityManagerFactory.createEntityManager();
        EntityTransaction transaction = entityManager.getTransaction();
        transaction.begin();

        entityManager.merge(person);
        //person is in Managed state

        transaction.commit();
        //person saved in the db
        
        entityManager.close();
        //person is Detached
    }
}
