package ro.ubb.lazy.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ro.ubb.lazy.model.Author;
import ro.ubb.lazy.repository.AuthorRepository;

import java.util.List;

/**
 * Created by radu.
 */
@Service
public class AuthorServiceImpl implements AuthorService {

    @Autowired
    private AuthorRepository authorRepository;

    @Override
    @Transactional
    public List<Author> findAll() {
        List<Author> all = authorRepository.findAll();
        System.out.println("**************** service-findAll");
        all.forEach(a -> {
            System.out.println("**************** service-books ");
            int n = a.getBooks().size();
        });

        return all;
    }

    @Override
    public void save(Author author) {
        authorRepository.save(author);
    }
}
