package ro.ubb.lazy.model;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(Publisher.class)
public abstract class Publisher_ extends ro.ubb.lazy.model.BaseEntity_ {

	public static volatile SingularAttribute<Publisher, String> name;

}

