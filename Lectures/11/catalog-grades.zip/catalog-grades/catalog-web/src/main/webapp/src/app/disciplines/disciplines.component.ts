import {Component} from "@angular/core";

@Component({
  moduleId: module.id,
  selector: 'ubb-disciplines',
  templateUrl: './disciplines.component.html',
  styleUrls: ['./disciplines.component.css'],
})
export class DisciplinesComponent {

}
